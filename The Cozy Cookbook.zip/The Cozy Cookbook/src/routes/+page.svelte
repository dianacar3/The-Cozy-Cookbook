<script>
	let recipeName = $state('');
	let ingredients = $state('');
	let instructions = $state('');

	/** @type {{name: string, ingredients: string, instructions: string} | null} */
	let selectedRecipe = $state(null);

	/** @type {{name: string, ingredients: string, instructions: string}[]} */
	let recipes = $state([]);

	function addRecipe() {
		if (
			recipeName.trim() === '' ||
			ingredients.trim() === '' ||
			instructions.trim() === ''
		) {
			return;
		}

		recipes.push({
			name: recipeName,
			ingredients: ingredients,
			instructions: instructions
		});

		recipeName = '';
		ingredients = '';
		instructions = '';
	}

	/**
	 * @param {{name: string, ingredients: string, instructions: string}} recipe
	 */
	function selectRecipe(recipe) {
		selectedRecipe = recipe;
	}

    function deleteRecipe() {
        if (selectedRecipe === null) {
            return;
        }

        recipes = recipes.filter((recipe) => recipe !== selectedRecipe);
        selectedRecipe = null;
    }
</script>

<main class="page">
	<div class="cookbook">

		<!-- Header -->
        <header>
            <div class="header-content">

                <div class="header-text">
                    <h1>The Cozy Cookbook</h1>
                    <p>My favorite recipes in one place</p>
                </div>

                <img
                    class="chef-image"
                    src="/images/Cookbook.png"
                    alt="Cozy Cookbook chef illustration"
                />

            </div>
        </header>

        <!-- Main Cookbook Area -->
        <section class="recipe-area">

            <!-- Recipe List -->
            <div class="recipe-list">
                <h2>My Recipes</h2>

                {#if recipes.length === 0}
                    <p class="empty-message">No recipes added yet.</p>
                {:else}
                    {#each recipes as recipe}
                        <button type="button" class="recipe-item" onclick={() => selectRecipe(recipe)}>
                            {recipe.name}
                        </button>
                    {/each}
                {/if}
            </div>

            <!-- Recipe Details -->
            <div class="recipe-details">
                <h2>Recipe Details</h2>

                {#if selectedRecipe}
                    <h3>{selectedRecipe.name}</h3>

                    <h4>Ingredients</h4>
                    <p>{selectedRecipe.ingredients}</p>

                    <h4>Preparation Instructions</h4>
                    <p>{selectedRecipe.instructions}</p>

                    <button
                        type="button"
                        class="delete-button"
                        onclick={deleteRecipe}
                    >
                        Delete Recipe
                    </button>
                {:else}
                    <p>Select a recipe to view the details.</p>
                {/if}
            </div>

        </section>

        <!-- Add Recipe Form -->
        <section class="add-recipe">
            <h2>Add a New Recipe</h2>

            <div class="form-group">
                <label for="recipe-name">Recipe Name</label>
                <input
                    id="recipe-name"
                    type="text"
                    placeholder="Enter recipe name"
                    bind:value={recipeName}
                />
            </div>

            <div class="form-group">
                <label for="ingredients">Ingredients</label>
                <textarea
                    id="ingredients"
                    placeholder="Enter ingredients"
                    bind:value={ingredients}
                ></textarea>
            </div>

            <div class="form-group">
                <label for="instructions">Preparation Instructions</label>
                <textarea
                    id="instructions"
                    placeholder="Enter preparation instructions"
                    bind:value={instructions}
                ></textarea>
            </div>

            <button type="button" class="add-button" onclick={addRecipe}>Add Recipe</button>
        </section>

	</div>
</main>

<style>
@import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Nunito:wght@400;600;700&display=swap');

	:global(body) {
		margin: 0;
		font-family: 'Nunito', sans-serif;
		background-color: #f7eee7;
	}

	.page {
		min-height: 100vh;
		padding: 40px 20px;
		box-sizing: border-box;
	}

	.cookbook {
		max-width: 1000px;
		margin: 0 auto;
		background-color: #fffaf5;
		border-radius: 20px;
		overflow: hidden;
		box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
	}

	header {
		text-align: center;
		background-color: #a8b98a;
		padding: 30px 20px;
	}

    .header-content {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 35px;
    }

    .header-text {
        text-align: center;
    }

    .chef-image {
        width: 250px;
        max-width: 40%;
        height: auto;
    }

	h1 {
		margin: 0;
        font-family: 'Fredoka', sans-serif;
		font-size: 42px;
        font-weight: 700;
		color: #5c4033;
	}

	header p {
		margin: 8px 0 0;
		color: #5c4033;
		font-size: 17px;
	}

    .recipe-area {
	display: grid;
	grid-template-columns: 1fr 2fr;
	min-height: 300px;
    }

    .recipe-list {
        padding: 30px;
        background-color: #f8dce2;
        border-right: 2px solid #ead8ce;
    }

    .recipe-details {
        padding: 30px;
        background-color: #fffaf5;
    }

    h2 {
        font-family: 'Fredoka', sans-serif;
        color: #5c4033;
        margin-top: 0;
    }

    .recipe-area p {
        color: #795f52;
    }

    .empty-message {
        font-style: italic;
    }

    .add-recipe {
	padding: 30px;
	background-color: #fff2e8;
	border-top: 2px solid #ead8ce;
    }

    .add-recipe h2 {
        text-align: center;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 18px;
    }

    .form-group label {
        font-family: 'Fredoka', sans-serif;
        font-weight: 600;
        color: #5c4033;
        margin-bottom: 6px;
    }

    .form-group input,
    .form-group textarea {
        font-family: 'Nunito', sans-serif;
        font-size: 16px;
        padding: 12px;
        border: 2px solid #d9c5b8;
        border-radius: 10px;
        background-color: white;
        box-sizing: border-box;
    }

    .form-group textarea {
        min-height: 90px;
        resize: vertical;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        outline: none;
        border-color: #a8b98a;
    }

    .add-button {
        display: block;
        margin: 10px auto 0;
        padding: 12px 30px;
        border: none;
        border-radius: 12px;
        background-color: #a8b98a;
        color: #5c4033;
        font-family: 'Fredoka', sans-serif;
        font-size: 17px;
        font-weight: 600;
        cursor: pointer;
    }

    .add-button:hover {
        background-color: #91a573;
        transform: translateY(-2px);
    }

    .recipe-item {
	display: block;
	width: 100%;
	text-align: left;
	border: none;
	background-color: #fffaf5;
	color: #5c4033;
	padding: 12px;
	margin-bottom: 10px;
	border-radius: 10px;
	font-family: 'Fredoka', sans-serif;
	font-size: 16px;
	font-weight: 500;
	cursor: pointer;
	transition: 0.2s ease;
    }

    .recipe-item:hover {
        background-color: #f3e5dc;
        transform: translateY(-2px);
    }

    .recipe-details h3 {
        font-family: 'Fredoka', sans-serif;
        color: #718355;
        font-size: 26px;
        margin-bottom: 20px;
    }

    .recipe-details h4 {
        font-family: 'Fredoka', sans-serif;
        color: #5c4033;
        margin-bottom: 5px;
    }

    .recipe-details p {
        margin-top: 0;
    }

    .delete-button {
        margin-top: 15px;
        padding: 10px 18px;
        border: none;
        border-radius: 10px;
        background-color: #f4b8c4;
        color: #5c4033;
        font-family: 'Fredoka', sans-serif;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s ease;
    }

    .delete-button:hover {
        background-color: #e9a5b4;
        transform: translateY(-2px);
    }

    @media (max-width: 700px) {
        .page {
            padding: 20px 10px;
        }

        .header-content {
            flex-direction: column;
            gap: 15px;
        }

        .chef-image {
            width: 180px;
            max-width: 70%;
        }

        h1 {
            font-size: 32px;
        }

        .recipe-area {
            grid-template-columns: 1fr;
        }

        .recipe-list {
            border-right: none;
            border-bottom: 2px solid #ead8ce;
        }

        .recipe-list,
        .recipe-details,
        .add-recipe {
            padding: 20px;
        }
    }
    </style>
